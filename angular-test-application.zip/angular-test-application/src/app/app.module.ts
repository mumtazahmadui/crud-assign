import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { UsersPageComponent } from './users-page/users-page.component';
import { AppRoutingModule } from './app.routes';
import { HttpClientModule } from '@angular/common/http';
import { BootstrapModule } from './shared/bootstrap/bootstrap.module';
import { UserAddComponent } from './users-page/user-add/user-add.component';
import { FormsModule } from '@angular/forms';
import { UserDeleteComponent } from './users-page/user-delete/user-delete.component';

@NgModule({
  declarations: [
    AppComponent,
    UsersPageComponent,
    UserAddComponent,
    UserDeleteComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    BootstrapModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
