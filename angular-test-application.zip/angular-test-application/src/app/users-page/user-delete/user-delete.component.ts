import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-user-delete',
  templateUrl: './user-delete.component.html',
  styleUrls: ['./user-delete.component.css']
})
export class UserDeleteComponent {
  onConfirm: Function;
  data: any;
  isInvalid: boolean;
  isError: boolean | string;

  constructor(public bsModalRef: BsModalRef, private userService: UserService) { }

  deleteUsers(){
    this.isInvalid = true; 
    this.userService.deleteUsers(this.data.email).subscribe(
      (res) => {
        this.isInvalid = false;
        this.onConfirm(res)
      },
      (err) =>{
        this.isInvalid = false;
        this.isError = false;
        if(err.status === 200) {
          this.bsModalRef.hide()
          this.onConfirm(this.data)
        } else if(err.status === 400) {
          this.isError = 'There is some Unknown Error. Please Try again After some time.';
        }
      }
    );
    
  }
}
