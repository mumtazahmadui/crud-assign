import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { User, UserService } from './../service/user.service';

@Component({
  selector: 'app-user-add',
  templateUrl: './user-add.component.html',
  styleUrls: ['./user-add.component.css']
})
export class UserAddComponent {

  data: any;
  userValue: any = {};
  isInvalid: boolean;
  isValidEmail: boolean;
  emailPattern = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}";
  onConfirm: Function;

  constructor(public bsModalRef: BsModalRef, private userService: UserService) { }

  validateEmail(eve:string){
    this.isValidEmail = false;
    if (this.data.find(name => name.email == eve)) {
      this.isValidEmail = true;
    }
  }

  addUsers(data: User) {
    this.isInvalid = true;    
    this.userService.addUsers(data).subscribe(
      (res) => {
        this.isInvalid = false;
        this.bsModalRef.hide()
        this.onConfirm(res)
      },
      (err) => console.log(err)
    );
  }

}
