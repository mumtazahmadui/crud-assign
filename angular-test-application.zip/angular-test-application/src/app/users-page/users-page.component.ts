import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { User, UserService } from './service/user.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { UserAddComponent } from './user-add/user-add.component';
import { UserDeleteComponent } from './user-delete/user-delete.component';

const BsModalRefConfig = {
  ignoreBackdropClick: true,
  keyboard: false,
  class: 'modal-md-6'
}

@Component({
  selector: 'app-users-page',
  templateUrl: './users-page.component.html',
  styleUrls: ['./users-page.component.scss']
})
export class UsersPageComponent implements OnInit {
  //users$:Observable<any>;
  bsModalRef: BsModalRef;
  users:any;
  constructor(private userService: UserService,  private modalService: BsModalService,) { }

  ngOnInit(){
   // this.users$ = this.userService.getUsers()
   this.getUsers()
  }

  getUsers(){
    this.userService.getUsers().subscribe(
      (res:any) => this.users = res
    )
  }

  onAddUser(): void {
    // TODO: implement add user
    this.bsModalRef = this.modalService.show(UserAddComponent, BsModalRefConfig);
    this.bsModalRef.content.data = this.users;
    this.bsModalRef.content.onConfirm = (res: User) => {
      if(res.fullName) {
        this.users.push(res)
      }
    }
  }

  onDeleteUser(txt): void {
    // TODO: implement delete user
    this.bsModalRef = this.modalService.show(UserDeleteComponent, BsModalRefConfig);
    this.bsModalRef.content.data = txt;
    this.bsModalRef.content.onConfirm = (res: User) => {
      if(res.email) {
        this.users.pop(res.email)
      }
    }
  }

}
