import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface User { 
  email: string,
  fullName: string
};

@Injectable({
  providedIn: 'root'
})

export class UserService {

  constructor(private http: HttpClient) { }

  // Get Users
  getUsers():Observable<User[]> {
    return this.http.get<User[]>(`/api/users`);
  }

  // add Users
  addUsers(user:User):Observable<User[]> {
    return this.http.post<User[]>(`/api/users`, user);
  }

  // delete Users
  deleteUsers(email:string) {
    return this.http.delete<User[]>(`/api/users/${email}`);
  }

 

  
}
